export const defaultCell = {
  occupied: false,
  className: ""
};
